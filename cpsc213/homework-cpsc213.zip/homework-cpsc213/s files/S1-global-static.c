int a;
int b[10];

void foo () {
  a = 0; 
  b[a] = a;
}
